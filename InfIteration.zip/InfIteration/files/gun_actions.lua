local actions_to_edit = { -- New divides code
	{
	id          = "DIVIDE_2",
	action 		= function( recursion_level, iteration )
		c.fire_rate_wait = c.fire_rate_wait + 20
		
		local data = {}
		
		local iter = iteration or 1
		local iter_max = iteration or 1
		
		if ( #deck > 0 ) then
			data = deck[iter] or nil
		else
			data = nil
		end
		local count = 2
		local iterlim = ModSettingGet('InfIteration.div_no_limit')  -- Iteration limit on/off
		if not iterlim then
			if ( iter >= 5 ) then
				count = 1
			end
		end
		
		
		local rec = check_recursion( data, recursion_level )
		
		if ( data ~= nil ) and ( rec > -1 ) and ( ( data.uses_remaining == nil ) or ( data.uses_remaining ~= 0 ) ) then
			local firerate = c.fire_rate_wait
			local reload = current_reload_time
			
			for i=1,count do
				if ( i == 1 ) then
					dont_draw_actions = true
				end
				local imax = data.action( rec, iter + 1 )
				dont_draw_actions = false
				if (imax ~= nil) then
					iter_max = imax
				end
			end
			
			if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
				data.uses_remaining = data.uses_remaining - 1
				
				local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
				if not reduce_uses then
					data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction
				end
			end
			
			if (iter == 1) then
				c.fire_rate_wait = firerate
				current_reload_time = reload
				
				for i=1,iter_max do
					if (#deck > 0) then
						local d = deck[1]
						table.insert( discarded, d )
						table.remove( deck, 1 )
					end
				end
			end
		end
		
		local settdmg = ModSettingGet('InfIteration.dmg_penalty') -- damage penalty on/off
		if not settdmg then
			c.damage_projectile_add = c.damage_projectile_add - 0.2
		end
		local settexplrad = ModSettingGet('InfIteration.expl_rad_penalty')  -- explosion radius penalty on/off
		if not settexplrad then
			c.explosion_radius = c.explosion_radius - 5.0
			if (c.explosion_radius < 0) then
				c.explosion_radius = 0
			end
		end
		c.pattern_degrees = 5
		
		return iter_max
	end,
},
{
		id          = "DIVIDE_3",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 35
			
			local data = {}
			
			local iter = iteration or 1
			local iter_max = iteration or 1
			
			if ( #deck > 0 ) then
				data = deck[iter] or nil
			else
				data = nil
			end
			
			local count = 3
			local iterlim = ModSettingGet('InfIteration.div_no_limit')
			if not iterlim then
				if ( iter >= 4 ) then
					count = 1
				end
			end
			local rec = check_recursion( data, recursion_level )
			
			if ( data ~= nil ) and ( rec > -1 ) and ( ( data.uses_remaining == nil ) or ( data.uses_remaining ~= 0 ) ) then
				local firerate = c.fire_rate_wait
				local reload = current_reload_time
				
				for i=1,count do
					if ( i == 1 ) then
						dont_draw_actions = true
					end
					local imax = data.action( rec, iter + 1 )
					dont_draw_actions = false
					if (imax ~= nil) then
						iter_max = imax
					end
				end
				if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
					data.uses_remaining = data.uses_remaining - 1
					
					local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
					if not reduce_uses then
						data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction
					end
				end
				
				if (iter == 1) then
					c.fire_rate_wait = firerate
					current_reload_time = reload
					
					for i=1,iter_max do
						if (#deck > 0) then
							local d = deck[1]
							table.insert( discarded, d )
							table.remove( deck, 1 )
						end
					end
				end
			end
			
			local settdmg = ModSettingGet('InfIteration.dmg_penalty')
			if not settdmg then
				c.damage_projectile_add = c.damage_projectile_add - 0.4
			end
			local settexplrad = ModSettingGet('InfIteration.expl_rad_penalty')
			if not settexplrad then
				c.explosion_radius = c.explosion_radius - 10.0
				if (c.explosion_radius < 0) then
					c.explosion_radius = 0
				end
			end
			c.pattern_degrees = 5
			
			return iter_max
		end,
	},
	{
		id          = "DIVIDE_4",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 50
			
			local data = {}
			
			local iter = iteration or 1
			local iter_max = iteration or 1
			
			if ( #deck > 0 ) then
				data = deck[iter] or nil
			else
				data = nil
			end
			
			local count = 4
			local iterlim = ModSettingGet('InfIteration.div_no_limit')
			if not iterlim then
				if ( iter >= 4 ) then
					count = 1
				end
			end

			local rec = check_recursion( data, recursion_level )
			
			if ( data ~= nil ) and ( rec > -1 ) and ( ( data.uses_remaining == nil ) or ( data.uses_remaining ~= 0 ) ) then
				local firerate = c.fire_rate_wait
				local reload = current_reload_time
				
				for i=1,count do
					if ( i == 1 ) then
						dont_draw_actions = true
					end
					local imax = data.action( rec, iter + 1 )
					dont_draw_actions = false
					if (imax ~= nil) then
						iter_max = imax
					end
				end
				
				if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
					data.uses_remaining = data.uses_remaining - 1
					
					local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
					if not reduce_uses then
						data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction
					end
				end
				
				if (iter == 1) then
					c.fire_rate_wait = firerate
					current_reload_time = reload
					
					for i=1,iter_max do
						if (#deck > 0) then
							local d = deck[1]
							table.insert( discarded, d )
							table.remove( deck, 1 )
						end
					end
				end
			end
			
			local settdmg = ModSettingGet('InfIteration.dmg_penalty')
			if not settdmg then
				c.damage_projectile_add = c.damage_projectile_add - 0.6
			end
			local settexplrad = ModSettingGet('InfIteration.expl_rad_penalty')
			if not settexplrad then
				c.explosion_radius = c.explosion_radius - 20.0
				if (c.explosion_radius < 0) then
						c.explosion_radius = 0
				end
			end
			c.pattern_degrees = 5
			
			return iter_max
		end,
	},
	{
		id          = "DIVIDE_10",
		action 		= function( recursion_level, iteration )
			c.fire_rate_wait = c.fire_rate_wait + 80
			current_reload_time = current_reload_time + 20
			
			local data = {}
			
			local iter = iteration or 1
			local iter_max = iteration or 1
			
			if ( #deck > 0 ) then
				data = deck[iter] or nil
			else
				data = nil
			end
			
			local count = 10
			local iterlim = ModSettingGet('InfIteration.div_no_limit')
			if not iterlim then
				if ( iter >= 3 ) then
					count = 1
				end
			end
			
			local rec = check_recursion( data, recursion_level )
			
			if ( data ~= nil ) and ( rec > -1 ) and ( ( data.uses_remaining == nil ) or ( data.uses_remaining ~= 0 ) ) then
				local firerate = c.fire_rate_wait
				local reload = current_reload_time
				
				for i=1,count do
					if ( i == 1 ) then
						dont_draw_actions = true
					end
					local imax = data.action( rec, iter + 1 )
					dont_draw_actions = false
					if (imax ~= nil) then
						iter_max = imax
					end
				end
				
				if ( data.uses_remaining ~= nil ) and ( data.uses_remaining > 0 ) then
					data.uses_remaining = data.uses_remaining - 1
					
					local reduce_uses = ActionUsesRemainingChanged( data.inventoryitem_id, data.uses_remaining )
					if not reduce_uses then
						data.uses_remaining = data.uses_remaining + 1 -- cancel the reduction
					end
				end
				
				if (iter == 1) then
					c.fire_rate_wait = firerate
					current_reload_time = reload
					
					for i=1,iter_max do
						if (#deck > 0) then
							local d = deck[1]
							table.insert( discarded, d )
							table.remove( deck, 1 )
						end
					end
				end
			end

			local settdmg = ModSettingGet('InfIteration.dmg_penalty')
			if not settdmg then
				c.damage_projectile_add = c.damage_projectile_add - 1.5
			end
			local settexplrad = ModSettingGet('InfIteration.expl_rad_penalty')
			if not settexplrad then
				c.explosion_radius = c.explosion_radius - 40.0
				if (c.explosion_radius < 0) then
					c.explosion_radius = 0
				end
			end
			c.pattern_degrees = 5
			
			return iter_max
		end
	}
}

for i=1, #actions_to_edit do -- Change divides
	for i=1, #actions do
		for d=1, #actions_to_edit do
			if actions_to_edit[d]["id"] == actions[i]["id"] then
				actions[i]["action"] = actions_to_edit[d]["action"]
			end
		end
	end
end