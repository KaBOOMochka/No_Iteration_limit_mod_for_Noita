ModLuaFileAppend("data/scripts/gun/gun_actions.lua", "mods/InfIteration/files/gun_actions.lua")
-- Adds divide's code to the game