dofile("data/scripts/lib/mod_settings.lua")

local mod_id = "InfIteration"
local mod_settings_version = 1
local mod_settings = {
		{
			id = "div_no_limit",
			ui_name = "Remove iteration limit",
			ui_description = "Lets you divide infinitely",
			value_default = true,
			scope = MOD_SETTING_SCOPE_RUNTIME
		},
		{
			id = "dmg_penalty",
			ui_name = "Remove damage reduction",
			ui_description = "Removes damage reduction from Divides",
			value_default = false,
			scope = MOD_SETTING_SCOPE_RUNTIME
		},
		{
			id = "expl_rad_penalty",
			ui_name = "Remove explosion radius penalty",
			ui_description = "Removes explosion radius penalty from Divides",
			value_default = false,
			scope = MOD_SETTING_SCOPE_RUNTIME
		}
	}

function ModSettingsUpdate(init_scope)
    local old_version = mod_settings_get_version(mod_id)
    mod_settings_update(mod_id, mod_settings, init_scope)
end

function ModSettingsGuiCount()
	return mod_settings_gui_count( mod_id, mod_settings )
end

function ModSettingsGui( gui, in_main_menu )
	mod_settings_gui( mod_id, mod_settings, gui, in_main_menu )
end
